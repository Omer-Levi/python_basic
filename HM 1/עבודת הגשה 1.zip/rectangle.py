"""
Student: Omer Levi
ID: 203499090
Assignment no. 1
Program: rectangle.py
"""
num = int(input("Please enter the length of rectangle: "))
semel = input("Please enter a character: ")
print(semel *num)
print(semel,  (num-2)*" ", semel, sep="")
print(semel,  (num-2)*" ", semel, sep="")
print(semel *num)